// Global variables for app configuration
let appConfig = {
    channelName: 'Rythm Rise',
    channelDescription: 'Welcome to Rythm Rise - Your ultimate destination for amazing music content!',
    channelUrl: '#',
    bannerUrl: 'https://via.placeholder.com/1200x300/ff6b6b/ffffff?text=Rythm+Rise+Banner',
    iconUrl: 'https://via.placeholder.com/150x150/4ecdc4/ffffff?text=RR',
    apiKey: '',
    channelId: '',
    adminPassword: 'admin123' // Change this to a secure password
};

// YouTube API configuration
const YOUTUBE_API_BASE = 'https://www.googleapis.com/youtube/v3';

// DOM elements
let currentSection = 'latest';

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    loadStoredSettings();
    updateDisplayElements();
    setupEventListeners();
    
    // Load videos if API key and channel ID are available
    if (appConfig.apiKey && appConfig.channelId) {
        loadLatestVideos();
        loadPopularVideos();
        loadChannelInfo();
    } else {
        showDemoContent();
    }
});

// Setup event listeners
function setupEventListeners() {
    // Modal close functionality
    document.querySelector('.close').addEventListener('click', closeAdminModal);
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('adminModal');
        if (event.target === modal) {
            closeAdminModal();
        }
    });
    
    // Admin password enter key
    document.getElementById('adminPassword').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            adminLogin();
        }
    });
}

// Admin functionality
function openAdminModal() {
    document.getElementById('adminModal').style.display = 'block';
    document.getElementById('adminPassword').focus();
}

function closeAdminModal() {
    document.getElementById('adminModal').style.display = 'none';
    document.getElementById('adminPassword').value = '';
}

function adminLogin() {
    const password = document.getElementById('adminPassword').value;
    if (password === appConfig.adminPassword) {
        closeAdminModal();
        openAdminPanel();
        populateAdminForm();
    } else {
        alert('Incorrect password!');
    }
}

function openAdminPanel() {
    document.getElementById('adminPanel').classList.remove('hidden');
    document.getElementById('adminPanel').classList.add('active');
}

function closeAdminPanel() {
    document.getElementById('adminPanel').classList.remove('active');
    setTimeout(() => {
        document.getElementById('adminPanel').classList.add('hidden');
    }, 300);
}

function populateAdminForm() {
    document.getElementById('channelName').value = appConfig.channelName;
    document.getElementById('channelDesc').value = appConfig.channelDescription;
    document.getElementById('channelUrl').value = appConfig.channelUrl;
    document.getElementById('bannerUrl').value = appConfig.bannerUrl;
    document.getElementById('iconUrl').value = appConfig.iconUrl;
    document.getElementById('apiKey').value = appConfig.apiKey;
    document.getElementById('channelId').value = appConfig.channelId;
}

function saveSettings() {
    // Update configuration
    appConfig.channelName = document.getElementById('channelName').value;
    appConfig.channelDescription = document.getElementById('channelDesc').value;
    appConfig.channelUrl = document.getElementById('channelUrl').value;
    appConfig.bannerUrl = document.getElementById('bannerUrl').value;
    appConfig.iconUrl = document.getElementById('iconUrl').value;
    appConfig.apiKey = document.getElementById('apiKey').value;
    appConfig.channelId = document.getElementById('channelId').value;
    
    // Save to localStorage
    localStorage.setItem('rhythmRiseConfig', JSON.stringify(appConfig));
    
    // Update display elements
    updateDisplayElements();
    
    // Reload content if API credentials are provided
    if (appConfig.apiKey && appConfig.channelId) {
        loadLatestVideos();
        loadPopularVideos();
        loadChannelInfo();
    }
    
    alert('Settings saved successfully!');
    closeAdminPanel();
}

function loadStoredSettings() {
    const stored = localStorage.getItem('rhythmRiseConfig');
    if (stored) {
        appConfig = { ...appConfig, ...JSON.parse(stored) };
    }
}

function updateDisplayElements() {
    // Update channel name
    document.getElementById('displayChannelName').textContent = appConfig.channelName;
    document.getElementById('footerChannelName').textContent = appConfig.channelName;
    
    // Update channel description
    document.getElementById('displayChannelDesc').textContent = appConfig.channelDescription;
    
    // Update images
    document.getElementById('displayIcon').src = appConfig.iconUrl;
    document.getElementById('displayBanner').src = appConfig.bannerUrl;
    
    // Update subscribe links
    const subscribeButtons = [
        document.getElementById('subscribeBtn'),
        document.getElementById('footerSubscribe')
    ];
    
    subscribeButtons.forEach(btn => {
        if (btn && appConfig.channelUrl !== '#') {
            btn.href = appConfig.channelUrl;
        }
    });
    
    // Update page title
    document.title = `${appConfig.channelName} - Official YouTube Channel`;
}

// Navigation functionality
function showSection(sectionName) {
    // Hide all sections
    const sections = document.querySelectorAll('.video-section');
    sections.forEach(section => section.classList.remove('active'));
    
    // Show selected section
    document.getElementById(sectionName).classList.add('active');
    
    // Update navigation
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    event.target.classList.add('active');
    
    currentSection = sectionName;
}

// YouTube API functions
async function loadChannelInfo() {
    if (!appConfig.apiKey || !appConfig.channelId) return;
    
    try {
        const response = await fetch(
            `${YOUTUBE_API_BASE}/channels?part=statistics&id=${appConfig.channelId}&key=${appConfig.apiKey}`
        );
        
        if (!response.ok) throw new Error('Failed to fetch channel info');
        
        const data = await response.json();
        
        if (data.items && data.items.length > 0) {
            const stats = data.items[0].statistics;
            const subscriberCount = parseInt(stats.subscriberCount).toLocaleString();
            document.getElementById('subscriberCount').textContent = subscriberCount;
        }
    } catch (error) {
        console.error('Error loading channel info:', error);
        document.getElementById('subscriberCount').textContent = 'N/A';
    }
}

async function loadLatestVideos() {
    if (!appConfig.apiKey || !appConfig.channelId) return;
    
    const container = document.getElementById('latestVideos');
    container.innerHTML = '<div class="loading">Loading latest videos...</div>';
    
    try {
        const response = await fetch(
            `${YOUTUBE_API_BASE}/search?part=snippet&channelId=${appConfig.channelId}&maxResults=12&order=date&type=video&key=${appConfig.apiKey}`
        );
        
        if (!response.ok) throw new Error('Failed to fetch videos');
        
        const data = await response.json();
        displayVideos(data.items, container);
        
    } catch (error) {
        console.error('Error loading latest videos:', error);
        container.innerHTML = '<div class="loading">Unable to load videos. Please check your API configuration.</div>';
    }
}

async function loadPopularVideos() {
    if (!appConfig.apiKey || !appConfig.channelId) return;
    
    const container = document.getElementById('popularVideos');
    container.innerHTML = '<div class="loading">Loading popular videos...</div>';
    
    try {
        const response = await fetch(
            `${YOUTUBE_API_BASE}/search?part=snippet&channelId=${appConfig.channelId}&maxResults=12&order=viewCount&type=video&key=${appConfig.apiKey}`
        );
        
        if (!response.ok) throw new Error('Failed to fetch videos');
        
        const data = await response.json();
        displayVideos(data.items, container);
        
    } catch (error) {
        console.error('Error loading popular videos:', error);
        container.innerHTML = '<div class="loading">Unable to load videos. Please check your API configuration.</div>';
    }
}

function displayVideos(videos, container) {
    if (!videos || videos.length === 0) {
        container.innerHTML = '<div class="loading">No videos found.</div>';
        return;
    }
    
    const videosHTML = videos.map(video => {
        const thumbnail = video.snippet.thumbnails.medium.url;
        const title = video.snippet.title;
        const description = video.snippet.description.substring(0, 120) + '...';
        const publishedAt = new Date(video.snippet.publishedAt).toLocaleDateString();
        const videoUrl = `https://www.youtube.com/watch?v=${video.id.videoId}`;
        
        return `
            <div class="video-item" onclick="window.open('${videoUrl}', '_blank')">
                <div class="video-thumbnail">
                    <img src="${thumbnail}" alt="${title}" loading="lazy">
                    <div class="video-duration">▶</div>
                </div>
                <div class="video-info">
                    <h3 class="video-title">${title}</h3>
                    <div class="video-meta">
                        <span>Published: ${publishedAt}</span>
                    </div>
                    <p class="video-description">${description}</p>
                </div>
            </div>
        `;
    }).join('');
    
    container.innerHTML = `<div class="video-grid">${videosHTML}</div>`;
}

function showDemoContent() {
    // Show demo content when API is not configured
    const demoVideos = [
        {
            title: "Amazing Music Mix 2024",
            thumbnail: "https://via.placeholder.com/320x180/ff6b6b/ffffff?text=Music+Mix",
            description: "Check out our latest music mix featuring the best tracks of 2024...",
            date: "2024-01-15"
        },
        {
            title: "Behind the Scenes",
            thumbnail: "https://via.placeholder.com/320x180/4ecdc4/ffffff?text=Behind+Scenes",
            description: "Get an exclusive look behind the scenes of our latest production...",
            date: "2024-01-10"
        },
        {
            title: "Live Performance Highlights",
            thumbnail: "https://via.placeholder.com/320x180/45b7d1/ffffff?text=Live+Performance",
            description: "Highlights from our recent live performance featuring amazing tracks...",
            date: "2024-01-05"
        }
    ];
    
    displayDemoVideos(demoVideos, 'latestVideos');
    displayDemoVideos(demoVideos, 'popularVideos');
    document.getElementById('subscriberCount').textContent = '1,234';
}

function displayDemoVideos(videos, containerId) {
    const container = document.getElementById(containerId);
    const videosHTML = videos.map(video => `
        <div class="video-item" onclick="alert('Demo video - Configure YouTube API to load real content')">
            <div class="video-thumbnail">
                <img src="${video.thumbnail}" alt="${video.title}" loading="lazy">
                <div class="video-duration">▶</div>
            </div>
            <div class="video-info">
                <h3 class="video-title">${video.title}</h3>
                <div class="video-meta">
                    <span>Published: ${new Date(video.date).toLocaleDateString()}</span>
                </div>
                <p class="video-description">${video.description}</p>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = `<div class="video-grid">${videosHTML}</div>`;
}

// Utility functions
function formatDuration(duration) {
    // Convert ISO 8601 duration to readable format
    const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
    const hours = parseInt(match[1]) || 0;
    const minutes = parseInt(match[2]) || 0;
    const seconds = parseInt(match[3]) || 0;
    
    if (hours > 0) {
        return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    } else {
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
}

// Error handling for images
document.addEventListener('error', function(e) {
    if (e.target.tagName === 'IMG') {
        e.target.src = 'https://via.placeholder.com/320x180/cccccc/666666?text=Image+Not+Found';
    }
}, true);

// Service worker registration for offline functionality (optional)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // Service worker can be added later for offline functionality
    });
}